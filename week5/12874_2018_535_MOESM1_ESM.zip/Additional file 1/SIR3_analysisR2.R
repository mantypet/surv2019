library("survival")
library("cmprsk")
library("fmsb")

#setwd as appopriate

##################read data
base_mitstatus <- read.csv("base_mitstatus.csv")

data_necessary <- base_mitstatus[c(1,2,3,4,5,13)]

daten <- data_necessary[data_necessary$status==1,]


daten$event <- ifelse(daten$endpunkt == "Tod",daten$event <- 1,daten$event <- 2)


#cox model for death
summary(coxph(Surv(tag,event  == 1 ) ~ pneu_on_adm, data=daten))

#cox model for discharge
summary(coxph(Surv(tag,event == 2 ) ~ pneu_on_adm, data=daten))

#subdistribution (death)

#find maximum event time
maxevent <- max(daten$tag)

#censor competing event at maximum event time plus 1 day
daten$tag2 <- ifelse(daten$event == 2, maxevent + 1, daten$tag)

daten$outcome2 <- ifelse(daten$event == 2, 0, daten$event)

#cox subdistribution (death)
summary(coxph(Surv(tag2,outcome2 ==1) ~ pneu_on_adm, data=daten))

#####################odds ratios
##base_mitstatus
# find constant hazard equivalents
############## '02'-Hazard #################
#number of patient-days in 0
icu.inf <- daten[daten$pneu_on_adm == 0,]
pdays <- sum(icu.inf$tag)

#number of discharges without infection
death.in.0.data <- daten[daten$event == 1,] 
death.in.0 <- nrow(death.in.0.data[death.in.0.data$pneu_on_adm==0,])

#estimated constant hazard
con.haz03.tind <- death.in.0/pdays

############## '03'-Hazard #################
dis.in.0.data <- daten[daten$event == 2,]
dis.in.0 <- nrow(dis.in.0.data[dis.in.0.data$pneu_on_adm==0,])

#estimated constant hazard
con.haz02.tind <- dis.in.0/pdays

############## '12'-Hazard #################
death.in.1.data <- daten[daten$event == 1,]
death.in.1 <- nrow(death.in.1.data[death.in.1.data$pneu_on_adm==1,])

#number of patient-days in 1
icu.daysin1 <- daten[daten$pneu_on_adm == 1,]
pdaysin1 <- sum(icu.daysin1$tag)

#estimated constant hazard
con.haz13.tind <- death.in.1/pdaysin1

############## '13'-Hazard #################
dis.in.1.data <- daten[daten$event == 2,]
dis.in.1 <- nrow(dis.in.1.data[dis.in.1.data$pneu_on_adm==1,])

#estimated constant hazard
con.haz12.tind <- dis.in.1/pdaysin1

oddsratio(death.in.1,death.in.0,dis.in.1,dis.in.0)

#######################pneu_tdep zeitabh�ngig

pneu_tdep <- read.csv("pneu_tdep.csv")


test <- pneu_tdep[order(pneu_tdep$adm_id, pneu_tdep$start),]
indicator <- numeric()
n <- nrow(pneu_tdep)/2
n <- n-1

for(i in 1:n){
  
  if(test$status[2*i +1] == 0){ 
    indicator[2*i+1] <- 0
    indicator[2*i+2] <- 1
  } else {
    indicator[2*i+1] <- 1
    indicator[2*i+2] <- 0
  }
  
}

if(test$status[2033] == 0){ 
  indicator[2033] <- 0
  indicator[2034] <- 1
} else {
  indicator[2033] <- 1
  indicator[2034] <- 0
}

if(test$status[1] == 0){ 
  indicator[1] <- 0
  indicator[2] <- 1
} else {
  indicator[1] <- 1
  indicator[2] <- 0
}

test2 <- test[indicator==1,]
masque <- diff(test2$adm_id)
test2$from <- 0
test2$from[c(1, masque) == 0] <- 1
test2$to <- ifelse(test2$endpunkt == "Tod", test2$to <- 3, test2$to <- 2)
test2$to[test2$OUTCOME_REFERRED_TO == -1] <- "cens"
test2$to[c(masque, 1) == 0] <- 1
#remove consored observations
test2 <- test2[test2$OUTCOME_REFERRED_TO != -1,]
test2 <- data.frame(test2$adm_id, test2$start, test2$stop, test2$from, test2$to)
names(test2) <- c("id", "entry", "exit", "from","to")

for(i in 1:nrow(test2)){
  if(test2$to[i] == 1){
    test2$entry[i] <- 0
    test2$exit[i] <- test2$entry[i+1]
  }
}

test2$ status <- 1
test2[test2$to ==1,]$status <- 0
pneu_tdep2 <- test2

pneu_tdep2$outcome <- ifelse(pneu_tdep2$status==1, pneu_tdep2$to, 0)
###cause-specific analysis
#cox model for death
summary(coxph(Surv(entry, exit, outcome == 3) ~ from, data = pneu_tdep2))

#cox model for discharge
summary(coxph(Surv(entry, exit, outcome == 2) ~ from, data = pneu_tdep2))

####subdistribution analysis
#find maximum event time
maxtime <- max(pneu_tdep2$exit)

#censor competing event at maximum event time plus 1 day
pneu_tdep2$stop2 <- ifelse(pneu_tdep2$to == 2, maxtime + 1, pneu_tdep2$exit)

pneu_tdep2$outcome2 <- ifelse(pneu_tdep2$outcome == 2, 0, pneu_tdep2$outcome)

#cox subdistribution (death)
summary(coxph(Surv(entry,stop2,outcome2 == 3) ~ from, data=pneu_tdep2))

#####odds ratios
# find constant hazard equivalents
############## '01'-Hazard###################
#number of infections
infections <- nrow(pneu_tdep2[pneu_tdep2$to == 1,])

#number of patient-days in 0
icu.inf <- pneu_tdep2[pneu_tdep2$from == 0,]
pdays <- sum(icu.inf$exit -icu.inf$entry)

#estimated constant hazard
con.haz01 <- infections/pdays


############## '03'-Hazard #################
#number of deaths  without infections
death.in.0.data <- pneu_tdep2[pneu_tdep2$to == 3,]
death.in.0 <- nrow(death.in.0.data[death.in.0.data$from==0,])

#estimated constant hazard
con.haz03 <- death.in.0/pdays

############## '02'-Hazard #################
dis.in.0.data <- pneu_tdep2[pneu_tdep2$to == 2,]
dis.in.0 <- nrow(dis.in.0.data[dis.in.0.data$from==0,])

#estimated constant hazard
con.haz02 <- dis.in.0/pdays

############## '13'-Hazard #################
death.in.1.data <- pneu_tdep2[pneu_tdep2$to == 3,]
death.in.1 <- nrow(death.in.1.data[death.in.1.data$from==1,])

#number of patient-days in 1
icu.daysin1 <- pneu_tdep2[pneu_tdep2$from == 1,]
pdaysin1 <- sum(icu.daysin1$exit -icu.daysin1$entry)

#estimated constant hazard
con.haz13 <- death.in.1/pdaysin1

############## '12'-Hazard #################
dis.in.1.data <- pneu_tdep2[pneu_tdep2$to == 2,]
dis.in.1 <- nrow(dis.in.1.data[dis.in.1.data$from == 1,])

#estimated constant hazard
con.haz12 <- dis.in.1/pdaysin1

oddsratio(death.in.1,death.in.0,dis.in.1,dis.in.0)
