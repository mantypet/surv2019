#####time-independent setting, 2 cohorts in the beginning with either covariate status 1 or 0, merged afterwards
library("survival")
library("mvna")
library("cmprsk")
library("fmsb")

# hazards for simulating data

alpha02<- c(0.2,0.05,0.2,0.2,0.2)
alpha03<- c(0.05,0.01,0.05,0.1,0.05)
alpha14<- c(0.1,0.05,0.2,0.2,0.3)
alpha15<- c(0.05,0.01,0.1,0.075,0.05)

#include simulation code
source('Simulation_Crmit2.R')

set.seed(2790)
seeds <- sample(10000,size=100)

ors <- numeric()
ors_low <- numeric()
ors_up <- numeric()
sub_coef<- numeric()
sub_up <- numeric()
sub_low <- numeric()
sub_se <- numeric()
test_up <- numeric()
test_low <- numeric()
death <- numeric()
death_low <- numeric()
death_up <- numeric()
death_se <- numeric()
disch <- numeric()
disch_low <- numeric()
disch_up <- numeric()
disch_se <- numeric()
results <- data.frame()
k <- 1
t <- 1
#simulating 10000 individuals 
for(j in 1:5){
#100 cohorts
for(i in 1:100){
  set.seed(seeds[i])
simdata <- sim.cr(8000, alpha02[j], alpha03[j])
sim0 <- simdata
sim0$cov <- 0
sim0 <- data.frame(sim0$event,sim0$exit,sim0$cov)
names(sim0) <- c("event", "exit", "cov")

simdata <- sim.cr(2000, alpha14[j], alpha15[j])
sim1 <- simdata
sim1$cov <- 1
sim1 <- data.frame(sim1$event,sim1$exit,sim1$cov)
names(sim1) <- c("event", "exit", "cov")

data <- rbind(sim0,sim1)

##hazard ratio analysis
#'COx model for discharge'
fit <- coxph(Surv(exit,event == 1 ) ~ cov, data=data)
disch[i] <- fit$coef
disch_low[i] <- log(summary(fit)$conf.int[3])
disch_up[i] <- log(summary(fit)$conf.int[4])
disch_se[i] <- summary(fit)$coefficients[3]
#Cox model for death
fit <- coxph(Surv(exit,event == 2 ) ~ cov, data=data)
death[i] <- fit$coef
death_low[i] <- log(summary(fit)$conf.int[3])
death_up[i] <- log(summary(fit)$conf.int[4])
death_se[i] <- summary(fit)$coefficients[3]

#subdistribution hazard ratio

##censor competing event at latest event time to obtain subdistribution data
#find maximum event time
maxevent <- max(data$exit)

# censor competing event discharge alive(1)
data$status <- 1
data[data$event ==1,]$status <- 0
data[data$event ==1,]$exit <-  maxevent+1

# observed event indicator 
data$outcome <- with(data,status*event)

#Cox model 
fit <- coxph(Surv(exit,outcome !=0)~cov,data=data)
sub_coef[i]<- fit$coef
sub_low[i] <- log(summary(fit)$conf.int[3])
sub_up[i] <- log(summary(fit)$conf.int[4])
sub_se[i] <- summary(fit)$coefficients[3]

#odds ratio
n_exp_dis <- nrow(data[data$cov==1 & data$event==2,])
n_exp_nodis <- nrow(data[data$cov==1 & data$event==1,])
n_noexp_dis <- nrow(data[data$cov==0 & data$event==2,])
n_noexp_nodis <- nrow(data[data$cov==0 & data$event==1,])

ors[i] <-  oddsratio(n_exp_dis,n_noexp_dis,n_exp_nodis,n_noexp_nodis)$estimate
ors_low[i] <-  oddsratio(n_exp_dis,n_noexp_dis,n_exp_nodis,n_noexp_nodis)$conf.int[1]
ors_up[i] <-  oddsratio(n_exp_dis,n_noexp_dis,n_exp_nodis,n_noexp_nodis)$conf.int[2]
}
  ########death
  results[k,1] <- round(exp(mean(death)),2)
 #empirisches CI
   results[k,2] <- round(exp(quantile(death, 0.025)),2)
   results[k,3] <- round(exp(quantile(death, 0.975)),2)
 # CI basierend auf NV
   results[k,4] <- round(exp(mean(death) - qnorm(0.975) * sd(death)),2)
   results[k,5] <- round(exp(mean(death) + qnorm(0.975) * sd(death)),2)
  
   ######discharge
  results[k+1,1] <- round(exp(mean(disch)),2)
  #empirisches CI
  results[k+1,2] <- round(exp(quantile(disch, 0.025)),2)
  results[k+1,3] <- round(exp(quantile(disch, 0.975)),2)
  # CI basierend auf NV
  results[k+1,4] <- round(exp(mean(disch) - qnorm(0.975) * sd(disch)),2)
  results[k+1,5] <- round(exp(mean(disch) + qnorm(0.975) * sd(disch)),2)
  
  ####subdistribution
  results[k+2,1] <- round(exp(mean(sub_coef)),2)
  #empirisches CI
  results[k+2,2] <- round(exp(quantile(sub_coef, 0.025)),2)
  results[k+2,3] <- round(exp(quantile(sub_coef, 0.975)),2)
  # CI basierend auf NV
  results[k+2,4] <- round(exp(mean(sub_coef) - qnorm(0.975) * sd(sub_coef)),2)
  results[k+2,5] <- round(exp(mean(sub_coef) + qnorm(0.975) * sd(sub_coef)),2)
  
  
  ###OR
  results[k+3,1] <- round(mean(ors),2)
  #empirisches CI
  results[k+3,2] <- round(quantile(ors, 0.025),2)
  results[k+3,3] <- round(quantile(ors, 0.975),2)
  # CI basierend auf NV
  results[k+3,4] <- round(mean(ors) - qnorm(0.975) * sd(ors),2)
  results[k+3,5] <- round(mean(ors) + qnorm(0.975) * sd(ors),2)
  

t<- t +5
k <- k+4
}

View(results)
colnames(results) <- c("Mean Estimate","empiric_low","empiric_up", "NV_low","NV_up")
rownames(results) <- c("HR(death)_scenario0","HR (discharge)_scenario0", "SHR_scenario0", "OR_scenario0",
                       "HR(death)_scenario1","HR (discharge)_scenario1", "SHR_scenario1", "OR_scenario1",
                       "HR(death)_scenario2","HR (discharge)_scenario2", "SHR_scenario2", "OR_scenario2",
                       "HR(death)_scenario3","HR (discharge)_scenario3", "SHR_scenario3", "OR_scenario3",
                       "HR(death)_scenario4","HR (discharge)_scenario4", "SHR_scenario4", "OR_scenario4")
View(results)
write.csv(results,file="time_independent_setting.csv",row.names = TRUE)

