#simulates a cohort of size n with constant hazards except for alpha01(which jumps to 0.0001 after alpha01.jump.time)
sim.jump <- function(n, alpha01.jump, alpha01.jump.time, alpha02, alpha03, alpha14, alpha15){
  
  #data set 
  data <- list()
  
  #all individuals start in state 0 at time origin
  entry <- from <- rep(0,n)
  
  #modified times U
  
  my.times <- runif(n)
  
  for(i in 1:length(my.times)){
    
    if(-log(1-my.times[i]) <= (alpha01.jump.time *(alpha01.jump + alpha02+ alpha03)) )
    {
      my.times[i] <- (-log(1-my.times[i]))/(alpha01.jump + alpha02+ alpha03)
    }
    else{
      
      my.times[i] <- alpha01.jump.time-(log(1-my.times[i])+(alpha01.jump + alpha02+ alpha03)*alpha01.jump.time)/(0.0001 + alpha02+ alpha03)
    }
    
  }
  
  to <- numeric(n)
  #decide for state 1,2 or 3 with a multinomial experiment
  for(i in 1:n){
    if(my.times[i] <= alpha01.jump.time ){
      to[i] <- which(t(rmultinom(1, 1, c(alpha01.jump/(alpha01.jump+alpha02+alpha03),
                                         alpha02/(alpha01.jump+alpha02+alpha03),
                                         alpha03/(alpha01.jump+alpha02+alpha03))))==1)
      
    }
    else{
      to[i] <- which(t(rmultinom(1, 1, c(0.0001/(0.0001+alpha02+alpha03),
                                         alpha02/(0.0001+alpha02+alpha03),
                                         alpha03/(0.0001+alpha02+alpha03))))==1)
    }} 
  
  # set identification
  id <- seq_len(n)
  exit <- my.times
  
  # generate data set
  data[[1]] <- data.frame(id, from, to, entry, exit)
  
  
  #find the individuals who moved to 1
  temp <- data[[1]][data[[1]]$to == 1, ]
  
  #number of individuals who moved to 1
  n01 <- nrow(temp)
  
  #entry time into 1 is previous exit time
  temp$entry <- temp$exit
  
  #find new event times for moving into the final state(constant hazards!)
  temp$exit <- temp$exit + rexp(n01, alpha14 + alpha15)
  
  temp$from <- rep(1, n01)
  
  #finde cause of failure out of state 1
  cause <- rbinom(n01, size = 1, prob = alpha14 / (alpha14 + alpha15))
  temp$to <- ifelse(cause == 0, 5, 4)
  
  data[[2]] <- temp
  
  #full data set
  data <- do.call(rbind, data)
  
  data <- data.frame(data$id,data$from,data$to,data$entry,data$exit)
  names(data) <- c("id","from","to","entry","exit")
  data
}


