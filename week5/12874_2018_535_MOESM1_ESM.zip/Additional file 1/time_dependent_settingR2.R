############################################################
##    time-dependent setting: CSHR,SHR, OR                ##
############################################################

library("survival")
library("mvna")
library("cmprsk")
library("fmsb")

# hazards for simulating data
alpha01<- c(0.05,0.01,0.05,0.05,0.05)
alpha02<- c(0.2,0.05,0.2,0.2,0.2)
alpha03<- c(0.05,0.01,0.05,0.1,0.05)
alpha14<- c(0.1,0.05,0.2,0.2,0.3)
alpha15<- c(0.05,0.01,0.1,0.075,0.05)

#include simulation code for extended illness death model
source('Simulation_erweitertes_illness-death_Daten.R')

#simulating 10000 individuals 

set.seed(2790)
seeds <- sample(10000,size=100)

ors <- numeric()
ors_low <- numeric()
ors_up <- numeric()
sub_coef<- numeric()
sub_up <- numeric()
sub_low <- numeric()
test_up <- numeric()
test_low <- numeric()
death <- numeric()
death_low <- numeric()
death_up <- numeric()
disch <- numeric()
disch_low <- numeric()
disch_up <- numeric()
results <- data.frame()
k <- 1

#simulating 10000 individuals 
for(j in 1:5){
  #100 cohorts
  for(i in 1:100){
    set.seed(seeds[i])
simdata2 <- sim.data(10000, alpha01[j], alpha02[j], alpha03[j],alpha14[j], alpha15[j])

## Cox analysis of the simulated data
# transform simdata and add additional information
data <- simdata2[order(simdata2$id),]
data2 <- data[,c(1,4,5,3)]
data2$status <- 1
data2 <- cbind.data.frame(data2,data$from)
names(data2) <- c("id","start","stop","event","status","cov")
data2[data2$event ==4,]$event <- 2
data2[data2$event ==5,]$event <- 3
data2[data2$event ==1,]$status <- 0

#####cause-specific hazard ratios

data3 <- data2
data3$outcome <- with(data3,status*event)
#Cox model: HR for death
fit <-coxph(Surv(start,stop,outcome ==3)~cov,data=data3)
death[i] <- fit$coef
death_low[i] <- log(summary(fit)$conf.int[3])
death_up[i] <- log(summary(fit)$conf.int[4])

#Cox model: HR for discharge
fit <- coxph(Surv(start,stop,outcome ==2)~cov,data=data3)
disch[i] <- fit$coef
disch_low[i] <- log(summary(fit)$conf.int[3])
disch_up[i] <- log(summary(fit)$conf.int[4])


####subdistribution for death

##censor competing event at latest event time to obtain subdistribution data
#find maximum event time
maxevent <- max(simdata2$exit)
# censor competing event discharge alive(2)
data2[data2$event ==2,]$status <- 0
data2[data2$event ==2,]$stop <-  maxevent+1

# observed event indicator 
data2$outcome <- with(data2,status*event)

#Cox model 
fit <- coxph(Surv(start,stop,outcome !=0)~cov,data=data2)
sub_coef[i]<- fit$coef
sub_low[i] <- log(summary(fit)$conf.int[3])
sub_up[i] <- log(summary(fit)$conf.int[4])

#####odds ratio mit data2
#not exposed that died
noexp_death <- nrow(data[data$to==3,])

#not exposed that were discharged  
noexp_nodeath <- nrow(data[data$to==2,])

#exposed that were discharged
exp_nodeath <- nrow(data[data$to==4,])

#exposed that died
exp_death <- nrow(data[data$to==5,])

#oddsratio(exp_death, noexp_death, exp_nodeath, noexp_nodeath)
ors[i] <-  oddsratio(exp_death, noexp_death, exp_nodeath, noexp_nodeath)$estimate
ors_low[i] <-  oddsratio(n_exp_dis,n_noexp_dis,n_exp_nodis,n_noexp_nodis)$conf.int[1]
ors_up[i] <-  oddsratio(n_exp_dis,n_noexp_dis,n_exp_nodis,n_noexp_nodis)$conf.int[2]

}
  ########death
  results[k,1] <- round(exp(mean(death)),2)
  #empirisches CI
  results[k,2] <- round(exp(quantile(death, 0.025)),2)
  results[k,3] <- round(exp(quantile(death, 0.975)),2)
  # CI basierend auf NV
  results[k,4] <- round(exp(mean(death) - qnorm(0.975) * sd(death)),2)
  results[k,5] <- round(exp(mean(death) + qnorm(0.975) * sd(death)),2)
  
  ######discharge
  results[k+1,1] <- round(exp(mean(disch)),2)
  #empirisches CI
  results[k+1,2] <- round(exp(quantile(disch, 0.025)),2)
  results[k+1,3] <- round(exp(quantile(disch, 0.975)),2)
  # CI basierend auf NV
  results[k+1,4] <- round(exp(mean(disch) - qnorm(0.975) * sd(disch)),2)
  results[k+1,5] <- round(exp(mean(disch) + qnorm(0.975) * sd(disch)),2)
  
  ####subdistribution
  results[k+2,1] <- round(exp(mean(sub_coef)),2)
  #empirisches CI
  results[k+2,2] <- round(exp(quantile(sub_coef, 0.025)),2)
  results[k+2,3] <- round(exp(quantile(sub_coef, 0.975)),2)
  # CI basierend auf NV
  results[k+2,4] <- round(exp(mean(sub_coef) - qnorm(0.975) * sd(sub_coef)),2)
  results[k+2,5] <- round(exp(mean(sub_coef) + qnorm(0.975) * sd(sub_coef)),2)
  
  
  ###OR
  results[k+3,1] <- round(mean(ors),2)
  #empirisches CI
  results[k+3,2] <- round(quantile(ors, 0.025),2)
  results[k+3,3] <- round(quantile(ors, 0.975),2)
  # CI basierend auf NV
  results[k+3,4] <- round(mean(ors) - qnorm(0.975) * sd(ors),2)
  results[k+3,5] <- round(mean(ors) + qnorm(0.975) * sd(ors),2)
  
  
  t<- t +5
  k <- k+4
}

View(results)
colnames(results) <- c("Mean Estimate","empiric_low","empiric_up", "NV_low","NV_up")
rownames(results) <- c("HR(death)_scenario0","HR (discharge)_scenario0", "SHR_scenario0", "OR_scenario0",
                       "HR(death)_scenario1","HR (discharge)_scenario1", "SHR_scenario1", "OR_scenario1",
                       "HR(death)_scenario2","HR (discharge)_scenario2", "SHR_scenario2", "OR_scenario2",
                       "HR(death)_scenario3","HR (discharge)_scenario3", "SHR_scenario3", "OR_scenario3",
                       "HR(death)_scenario4","HR (discharge)_scenario4", "SHR_scenario4", "OR_scenario4")
View(results)
write.csv(results,file="time_dependent_setting.csv",row.names = TRUE)




