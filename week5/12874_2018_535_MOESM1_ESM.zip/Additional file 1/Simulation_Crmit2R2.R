#function to generate data with two competing risks
sim.cr <- function(n, alpha02, alpha03) {
  
  data <- list()
  
  entry <- rep(0, n)
  # event-times generieren, 1/(alpha02 + alpha03) average length of stay in ICU
  exit <- rexp(n, alpha02 + alpha03)
  
  event <- numeric(n)
  
  for (i in seq_len(n)) {
    event[i] <- which(t(rmultinom(1, 1, c(alpha02/(alpha01+alpha02+alpha03),
                                       alpha03/(alpha01+alpha02+alpha03))))==1)
  }
  
  id <- seq_len(n)
  
  data <- data.frame(id, event, entry, exit)

  
  data
}



